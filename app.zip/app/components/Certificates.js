/* eslint-disable @next/next/no-img-element */
'use client';
import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

export default function Certificates() {
  const [selectedCert, setSelectedCert] = useState(null);
  const [modalImgFailed, setModalImgFailed] = useState(false);

  // Reset status gambar setiap kali sertifikat yang dibuka berubah
  useEffect(() => {
    setModalImgFailed(false);
  }, [selectedCert]);

  // Tutup modal dengan tombol Escape
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && setSelectedCert(null);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const certificatesList = [
    {
      id: 1,
      title: "Sertifikasi Database Administrator",
      issuer: "Lembaga Sertifikasi / BNSP",
      date: "2025",
      icon: "fas fa-database",
      bgColor: "bg-blue-500/10 text-blue-400 border-blue-500/20",
      description: "Sertifikasi profesional yang memvalidasi kompetensi dalam merancang arsitektur database, optimasi query, manajemen penyimpanan, serta memastikan keamanan data pada sistem aplikasi.",
      image: "/cert-db.jpg" 
    },
    
    {
      id: 2,
      title: "Sertifikat TOK (Tenaga Operator Komputer)",
      issuer: "Lembaga Sertifikasi/ BNSP",
      date: "2024",
      icon: "fas fa-laptop-house",
      bgColor: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
      description: "Sertifikasi kompetensi yang membuktikan keahlian teknis dalam pengoperasian sistem komputer, manajemen berkas, efisiensi kerja digital, dan pemecahan masalah dasar pada perangkat keras & lunak.",
      image: "/sertifikat TOK.jpg"
    },

    {
      id: 3,
      title: "Presenter at IC-BESTS International Conference",
      issuer: "Politeknik LP3I Jakarta",
      date: "Juli 2026",
      icon: "fas fa-chalkboard-teacher", // Icon guru/presenter
      bgColor: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
      description: "Berpartisipasi aktif sebagai 'Member of Presenter' dalam ajang International Conference on Business, Economics, Technology, and Social (IC-BESTS) 2026. Pengalaman ini membuktikan kemampuan komunikasi profesional, public speaking, serta pemahaman komprehensif terhadap wawasan teknologi dan akademik global.",
      image: "/FALAAH HAMID HUTASOIT Member certificate_page-0001.jpg" // Ganti nama file ini sesuai dengan foto sertifikat yang kamu simpan di folder public
    }
  ];

  return (
    <section id="certificates" className="py-24 bg-[#050b1e] relative overflow-hidden">
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-600/10 rounded-full filter blur-3xl opacity-70 pointer-events-none"></div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="text-center mb-16">
          <h2 className="text-4xl font-extrabold text-slate-100 mb-4 tracking-tight">Sertifikat & Lisensi</h2>
          <p className="text-slate-400">Kredensial profesional untuk memvalidasi keahlian dan kompetensi teknis.</p>
          <div className="w-16 h-1 bg-blue-500 mx-auto rounded-full mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {certificatesList.map((cert) => (
            <motion.div
              key={cert.id}
              initial={{ y: 40, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: cert.id * 0.1 }}
              className="bg-[#0b1836] rounded-[2rem] p-8 border border-white/10 shadow-[0_4px_20px_rgba(0,0,0,0.2)] hover:shadow-[0_20px_40px_-15px_rgba(59,130,246,0.35)] hover:border-blue-500/40 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between group cursor-pointer"
              onClick={() => setSelectedCert(cert)} 
            >
              <div>
                {/* Thumbnail sertifikat (otomatis disembunyikan kalau gambar tidak ditemukan) */}
                <div className="relative -mx-8 -mt-8 mb-6 h-44 overflow-hidden rounded-t-[2rem] bg-[#071022]">
                  <img
                    src={cert.image}
                    alt={`Sertifikat ${cert.title}`}
                    loading="lazy"
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                    onError={(e) => { e.currentTarget.parentElement.style.display = "none"; }}
                  />
                </div>

                <div className="flex justify-between items-start mb-6">
                  <div className={`w-14 h-14 rounded-2xl ${cert.bgColor} border flex items-center justify-center text-2xl shadow-sm transition-transform duration-300 group-hover:scale-110`}>
                    <i className={cert.icon}></i>
                  </div>
                  <span className="px-3 py-1 bg-[#071022] border border-white/10 rounded-full text-xs font-semibold text-slate-400 tracking-wide">
                    {cert.date}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-slate-100 mb-1 group-hover:text-blue-400 transition-colors">
                  {cert.title}
                </h3>
                <p className="text-sm font-medium text-blue-400 mb-4 flex items-center gap-1.5">
                  <i className="fas fa-award text-xs"></i> {cert.issuer}
                </p>

                <p className="text-slate-400 leading-relaxed text-[14px]">
                  {cert.description}
                </p>
              </div>

              <div className="mt-8 pt-4 border-t border-white/10 flex justify-end">
                <span className="text-xs font-bold text-slate-400 group-hover:text-blue-400 transition-colors flex items-center gap-1">
                  Lihat sertifikat <i className="fas fa-eye ml-1"></i>
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* --- BAGIAN MODAL POP-UP --- */}
      <AnimatePresence>
        {selectedCert && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-900/80 backdrop-blur-sm"
            onClick={() => setSelectedCert(null)} // Tutup modal jika area luar diklik
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: "spring", bounce: 0.4, duration: 0.6 }}
              className="relative w-full max-w-4xl bg-[#0b1836] rounded-2xl overflow-hidden shadow-2xl border border-white/10"
              onClick={(e) => e.stopPropagation()} // Supaya kalau gambarnya diklik, modal nggak tertutup
            >
              {/* Tombol Close (X) */}
              <button 
                onClick={() => setSelectedCert(null)}
                aria-label="Tutup" className="absolute top-4 right-4 z-10 w-10 h-10 bg-black/50 hover:bg-red-500 text-white rounded-full flex items-center justify-center transition-colors duration-300"
              >
                <i className="fas fa-times text-lg"></i>
              </button>

              {/* Tempat Gambar Sertifikat */}
              <div className="w-full h-auto max-h-[80vh] overflow-y-auto p-2 bg-[#071022] flex items-center justify-center">
                {modalImgFailed ? (
                  <div className="w-full min-h-[280px] flex flex-col items-center justify-center gap-3 px-6 py-12 text-center">
                    <div className="w-16 h-16 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-3xl text-blue-400">
                      <i className="fas fa-image"></i>
                    </div>
                    <p className="text-base font-semibold text-slate-100">Gambar sertifikat belum diunggah</p>
                    <p className="text-sm text-slate-400 max-w-sm">File gambar untuk sertifikat ini belum diunggah, jadi belum bisa ditampilkan di sini.</p>
                  </div>
                ) : (
                  <img
                    src={selectedCert.image}
                    alt={selectedCert.title}
                    className="w-full h-auto object-contain rounded-xl"
                    onError={() => setModalImgFailed(true)}
                  />
                )}
              </div>
              
              {/* Keterangan di bawah gambar */}
              <div className="p-4 bg-[#0b1836] border-t border-white/10 text-center">
                <h4 className="text-lg font-bold text-slate-100">{selectedCert.title}</h4>
                <p className="text-sm text-slate-400">{selectedCert.issuer} • {selectedCert.date}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </section>
  );
}